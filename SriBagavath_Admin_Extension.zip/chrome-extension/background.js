import { firebaseConfig } from './firebase-config.js';

const API_KEY = firebaseConfig.apiKey;
const PROJECT_ID = firebaseConfig.projectId;

let lastKnownCount = 0;

// Initialize alarm with stored interval
chrome.storage.sync.get({ interval: 5 }, ({ interval }) => {
  chrome.alarms.create('check-notifications', { periodInMinutes: interval });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'check-notifications') {
    checkNotifications();
  }
});

async function checkNotifications() {
  const data = await chrome.storage.local.get(['idToken', 'uid', 'email', 'lastKnownCount']);
  if (!data.idToken) return;

  const lastKnownCount = data.lastKnownCount || 0;

  const settings = await chrome.storage.sync.get({
    registrations: true,
    purchases: true,
    donations: true
  });

  try {
    const totalPending = await fetchPendingCount(data.idToken, settings);
    updateBadge(totalPending);

    if (totalPending > lastKnownCount) {
      showNotification(totalPending);
      if (settings.beep) {
        playBeep();
      }
    }
    
    // Always update lastKnownCount in storage
    chrome.storage.local.set({ lastKnownCount: totalPending });
  } catch (e) {
    console.error("Fetch failed", e);
    if (e.message.includes('401')) {
      chrome.storage.local.remove(['idToken']);
    }
  }
}

// Open Admin Portal on click
chrome.notifications.onClicked.addListener(() => {
  chrome.tabs.create({ url: 'https://sribagavath-admin.web.app/admin-review' });
});

async function fetchPendingCount(token, settings) {
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents:runQuery`;
  
  const query = {
    structuredQuery: {
      from: [{ collectionId: 'transactions' }],
      where: {
        fieldFilter: {
          field: { fieldPath: 'status' },
          op: 'EQUAL',
          value: { stringValue: 'PENDING' }
        }
      }
    }
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}` },
    body: JSON.stringify(query)
  });

  if (!response.ok) throw new Error(`HTTP ${response.status}`);

  const results = await response.json();
  let count = 0;

  // results is an array of objects { document: { ... } }
  results.forEach(res => {
    if (!res.document) return;
    const fields = res.document.fields;
    const itemType = fields.itemType?.stringValue;

    if (itemType === 'PROGRAM' && settings.registrations) count++;
    else if ((itemType === 'BOOK' || itemType === 'MAGAZINE_SUBSCRIPTION') && settings.purchases) count++;
    else if (itemType === 'DONATION' && settings.donations) count++;
  });

  return count;
}

function updateBadge(count) {
  const text = count > 0 ? count.toString() : '';
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color: '#F44336' });
}

function showNotification(count) {
  chrome.notifications.create('admin-alert', {
    type: 'basic',
    iconUrl: chrome.runtime.getURL('icons/icon48.png'),
    title: 'Sri Bagavath Admin Alert 🚀',
    message: `There are ${count} pending transactions waiting for review.`,
    contextMessage: 'Click to open Admin Portal',
    priority: 2,
    requireInteraction: true
  });
}

// Initial check
checkNotifications();

// Listen for settings changes
chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
  if (request.action === 'recheck') {
    if (request.updateAlarm) {
      const { interval } = await chrome.storage.sync.get({ interval: 10 });
      chrome.alarms.create('check-notifications', { periodInMinutes: interval });
    }
    checkNotifications();
  } else if (request.action === 'play-test-beep') {
    playBeep();
  }
});

async function playBeep() {
  if (!(await chrome.offscreen.hasDocument?.() || false)) {
    try {
      await chrome.offscreen.createDocument({
        url: 'offscreen.html',
        reasons: ['AUDIO_PLAYBACK'],
        justification: 'Notification alert sound'
      });
    } catch (e) {
      console.error("Offscreen creation failed", e);
    }
  }
  chrome.runtime.sendMessage({
    target: 'offscreen',
    type: 'play-beep'
  });
}
