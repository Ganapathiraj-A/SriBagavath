function saveOptions() {
  const registrations = document.getElementById('registrations').checked;
  const purchases = document.getElementById('purchases').checked;
  const donations = document.getElementById('donations').checked;
  const beep = document.getElementById('beep').checked;
  const interval = parseInt(document.getElementById('interval').value);

  chrome.storage.sync.set(
    { registrations, purchases, donations, beep, interval },
    () => {
      const status = document.getElementById('status');
      status.classList.add('visible');
      setTimeout(() => {
        status.classList.remove('visible');
      }, 1500);
      
      // Notify background script to re-check and update alarm
      chrome.runtime.sendMessage({ action: 'recheck', updateAlarm: true });
    }
  );
}

function restoreOptions() {
  chrome.storage.sync.get(
    { registrations: true, purchases: true, donations: true, beep: true, interval: 5 },
    (items) => {
      document.getElementById('registrations').checked = items.registrations;
      document.getElementById('purchases').checked = items.purchases;
      document.getElementById('donations').checked = items.donations;
      document.getElementById('beep').checked = items.beep;
      document.getElementById('interval').value = items.interval;
    }
  );
}

document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('registrations').addEventListener('change', saveOptions);
document.getElementById('purchases').addEventListener('change', saveOptions);
document.getElementById('donations').addEventListener('change', saveOptions);
document.getElementById('beep').addEventListener('change', saveOptions);
document.getElementById('interval').addEventListener('change', saveOptions);

document.getElementById('test-beep').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'play-test-beep' });
});

document.getElementById('test-notify').addEventListener('click', () => {
  chrome.notifications.create('test-alert', {
    type: 'basic',
    iconUrl: chrome.runtime.getURL('icons/icon48.png'),
    title: 'Test Notification ✅',
    message: 'Notifications are working! You will see real alerts when new items arrive.',
    priority: 2,
    requireInteraction: false
  });
});


document.getElementById('scan-now').addEventListener('click', () => {
  const btn = document.getElementById('scan-now');
  const originalText = btn.textContent;
  btn.textContent = 'Scanning...';
  btn.disabled = true;

  chrome.runtime.sendMessage({ action: 'recheck' }, () => {
    // Give it a moment to feel like work happened
    setTimeout(() => {
      btn.textContent = originalText;
      btn.disabled = false;
    }, 1000);
  });
});

function updateTimer() {
  chrome.alarms.get('check-notifications', (alarm) => {
    const display = document.getElementById('next-scan');
    if (!alarm) {
      display.textContent = 'Paused (Not Logged In)';
      return;
    }

    const diff = Math.max(0, alarm.scheduledTime - Date.now());
    const mins = Math.floor(diff / 60000);
    const secs = Math.floor((diff % 60000) / 1000);
    
    display.textContent = `${mins}:${secs.toString().padStart(2, '0')}`;
  });
}

// Update timer every second
setInterval(updateTimer, 1000);
updateTimer();
