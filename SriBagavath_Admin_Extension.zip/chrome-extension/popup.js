import { firebaseConfig } from './firebase-config.js';

const API_KEY = firebaseConfig.apiKey;
const PROJECT_ID = firebaseConfig.projectId;

const loginForm = document.getElementById('login-form');
const dashboard = document.getElementById('dashboard');
const loading = document.getElementById('loading');
const loginBtn = document.getElementById('login-btn');
const googleLoginBtn = document.getElementById('google-login-btn');
const refreshBtn = document.getElementById('refresh-btn');
const logoutBtn = document.getElementById('logout-btn');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const userEmailSpan = document.getElementById('user-email');
const loginError = document.getElementById('login-error');

// Check local storage for session
chrome.storage.local.get(['idToken', 'email'], (data) => {
  loading.classList.add('hidden');
  if (data.idToken) {
    showDashboard(data.email);
  } else {
    showLogin();
  }
});

function showLogin() {
  loginForm.classList.remove('hidden');
  dashboard.classList.add('hidden');
  userEmailSpan.textContent = '';
}

async function showDashboard(email) {
  loginForm.classList.add('hidden');
  dashboard.classList.remove('hidden');
  userEmailSpan.textContent = email;
  refreshStats();
}

async function refreshStats() {
  const data = await chrome.storage.local.get(['idToken']);
  if (!data.idToken) return;

  try {
    const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents:runQuery`;
    const query = {
      structuredQuery: {
        from: [{ collectionId: 'transactions' }],
        where: {
          fieldFilter: {
            field: { fieldPath: 'status' },
            op: 'EQUAL',
            value: { stringValue: 'PENDING' }
          }
        }
      }
    };

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${data.idToken}` },
      body: JSON.stringify(query)
    });

    const results = await response.json();
    let regs = 0; let purchases = 0; let donations = 0;

    if (Array.isArray(results)) {
      results.forEach(res => {
        if (!res.document) return;
        const fields = res.document.fields;
        const itemType = fields.itemType?.stringValue;
        if (itemType === 'PROGRAM') regs++;
        else if (itemType === 'BOOK' || itemType === 'MAGAZINE_SUBSCRIPTION') purchases++;
        else if (itemType === 'DONATION') donations++;
      });
    }

    document.getElementById('reg-count').textContent = regs;
    document.getElementById('purchase-count').textContent = purchases;
    document.getElementById('donation-count').textContent = donations;
  } catch (e) {
    console.error("Stats refresh failed", e);
  }
}

loginBtn.addEventListener('click', async () => {
  const email = emailInput.value.toLowerCase().trim();
  const password = passwordInput.value;
  if (!email || !password) return;

  loginBtn.disabled = true;
  loginError.classList.add('hidden');

  try {
    const authUrl = `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${API_KEY}`;
    const authRes = await fetch(authUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, returnSecureToken: true })
    });

    const authData = await authRes.json();
    if (!authRes.ok) throw new Error(authData.error?.message || "Login failed");

    const isAdmin = await verifyAdmin(authData.idToken, authData.localId, email);
    if (!isAdmin) throw new Error("Unauthorized: Not an admin.");

    await chrome.storage.local.set({
      idToken: authData.idToken,
      uid: authData.localId,
      email: email
    });

    showDashboard(email);
    chrome.runtime.sendMessage({ action: 'recheck' });

  } catch (err) {
    loginError.textContent = err.message;
    loginError.classList.remove('hidden');
  } finally {
    loginBtn.disabled = false;
  }
});

googleLoginBtn.addEventListener('click', () => {
  googleLoginBtn.disabled = true;
  loginError.classList.add('hidden');

  chrome.identity.getAuthToken({ interactive: true }, async (token) => {
    if (chrome.runtime.lastError || !token) {
      loginError.textContent = chrome.runtime.lastError?.message || "Google Login failed";
      loginError.classList.remove('hidden');
      googleLoginBtn.disabled = false;
      return;
    }

    try {
      // 1. Get User Email from Google
      const userRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const userData = await userRes.json();
      const email = userData.email;

      // 2. Exchange Google Token for Firebase ID Token
      const fbUrl = `https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=${API_KEY}`;
      const fbRes = await fetch(fbUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          postBody: `access_token=${token}&providerId=google.com`,
          requestUri: 'http://localhost',
          returnSecureToken: true
        })
      });

      const fbData = await fbRes.json();
      if (!fbRes.ok) throw new Error(fbData.error?.message || "Firebase Link failed");

      // 3. Verify Admin
      const isAdmin = await verifyAdmin(fbData.idToken, fbData.localId, email);
      if (!isAdmin) throw new Error("Unauthorized: Your Google account is not an admin.");

      await chrome.storage.local.set({
        idToken: fbData.idToken,
        uid: fbData.localId,
        email: email
      });

      showDashboard(email);
      chrome.runtime.sendMessage({ action: 'recheck' });

    } catch (err) {
      loginError.textContent = err.message;
      loginError.classList.remove('hidden');
    } finally {
      googleLoginBtn.disabled = false;
    }
  });
});

async function verifyAdmin(token, uid, email) {
  const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents:runQuery`;
  
  const query = {
    structuredQuery: {
      from: [{ collectionId: 'admins' }],
      where: {
        fieldFilter: {
          field: { fieldPath: 'email' },
          op: 'EQUAL',
          value: { stringValue: email.toLowerCase().trim() }
        }
      }
    }
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${token}` },
    body: JSON.stringify(query)
  });

  const results = await response.json();
  if (!Array.isArray(results)) return false;
  return results.some(r => r.document);
}

logoutBtn.addEventListener('click', () => {
  chrome.storage.local.remove(['idToken', 'uid', 'email'], () => {
    showLogin();
    // Also clear Google token so user can switch accounts if needed
    chrome.identity.getAuthToken({ interactive: false }, (token) => {
      if (token) chrome.identity.removeCachedAuthToken({ token });
    });
    chrome.runtime.sendMessage({ action: 'recheck' });
  });
});

refreshBtn.addEventListener('click', async () => {
  refreshBtn.classList.add('spinning');
  await refreshStats();
  // Delay slightly to show the animation
  setTimeout(() => refreshBtn.classList.remove('spinning'), 500);
});

// Deep Link Navigation
const ADMIN_BASE = 'https://sribagavath-admin.web.app';

document.getElementById('reg-card').addEventListener('click', () => {
  chrome.tabs.create({ url: `${ADMIN_BASE}/admin-review` });
});

document.getElementById('purchase-card').addEventListener('click', () => {
  chrome.tabs.create({ url: `${ADMIN_BASE}/admin/purchases` });
});

document.getElementById('donation-card').addEventListener('click', () => {
  chrome.tabs.create({ url: `${ADMIN_BASE}/admin/donations` });
});
