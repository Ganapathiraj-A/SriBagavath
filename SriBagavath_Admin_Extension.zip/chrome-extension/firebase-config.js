export const firebaseConfig = {
  apiKey: "AIzaSyAKduVLomDvJtkYJV_yK27h6-WgU76FSpE",
  authDomain: "antigravity-app-5c1ff.firebaseapp.com",
  projectId: "antigravity-app-5c1ff",
  storageBucket: "antigravity-app-5c1ff.firebasestorage.app",
  messagingSenderId: "358075696780",
  appId: "1:358075696780:web:c27e343cb4df4fa789dda9",
  measurementId: "G-6D7JC3KBF5"
};
