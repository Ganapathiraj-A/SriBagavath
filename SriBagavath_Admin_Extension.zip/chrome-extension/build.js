import * as esbuild from 'esbuild';

const build = async () => {
  try {
    console.log('Building extension...');
    await esbuild.build({
      entryPoints: [
        'chrome-extension/background.js',
        'chrome-extension/popup.js',
        'chrome-extension/options.js',
        'chrome-extension/offscreen.js'
      ],
      bundle: true,
      minify: false,
      format: 'esm',
      outdir: 'chrome-extension/dist',
      sourcemap: false,
      platform: 'browser',
      target: ['chrome100'],
      loader: { '.js': 'js' },
      define: {
        'process.env.NODE_ENV': '"production"'
      }
    });
    console.log('Build successful! Files are in chrome-extension/dist');
  } catch (e) {
    console.error('Build failed:', e);
    process.exit(1);
  }
};

build();
